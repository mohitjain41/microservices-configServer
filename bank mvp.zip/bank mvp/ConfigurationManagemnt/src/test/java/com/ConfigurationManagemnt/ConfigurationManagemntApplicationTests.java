package com.ConfigurationManagemnt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationManagemntApplicationTests {

	@Test
	void contextLoads() {
	}

}
