package com.AccountManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
