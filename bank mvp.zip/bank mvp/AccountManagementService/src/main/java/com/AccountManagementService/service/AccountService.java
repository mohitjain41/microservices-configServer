package com.AccountManagementService.service;

// AccountService.java

import com.AccountManagementService.entity.Account;
import com.AccountManagementService.entity.AccountDetailsResponse;
import com.AccountManagementService.entity.Customer;
import com.AccountManagementService.exception.CustomerNotFoundException;
import com.AccountManagementService.exception.InsufficientFundsException;
import com.AccountManagementService.feign.CustomerManagementClient;
import com.AccountManagementService.repository.AccountRepository;
import feign.FeignException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AccountService {

    private static final String CUSTOMER_NOT_FOUND_MESSAGE = "Customer not found with id: ";
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CustomerManagementClient customerManagementClient;

    public String addMoneyToAccount(Long customerId, double amount) {
        validateCustomer(customerId);
        Account account = getOrCreateAccount(customerId);
        account.setBalance(account.getBalance() + amount);
        accountRepository.save(account);
        return "money added successfully to the account";
    }



    public String withdrawMoneyFromAccount(Long customerId, double amount) {
        validateCustomer(customerId);
        Account account = getOrCreateAccount(customerId);
        if (account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            accountRepository.save(account);
            return "Money withdrawn from account. To check remaining balance go to details.";
        } else {
            throw new InsufficientFundsException("Insufficient balance in the account");
        }
    }

    public AccountDetailsResponse getAccountDetails(Long customerId) {
        validateCustomer(customerId);
        Account account = getOrCreateAccount(customerId);
        Customer customer = customerManagementClient.getCustomerDetails(customerId);
        return new AccountDetailsResponse(account, customer);

    }

    @Transactional
    public String deleteAccount(Long customerId) {
        validateCustomer(customerId);
        // Delete the account
        Optional<Account> accountOptional = accountRepository.findByCustomerId(customerId);
        accountOptional.ifPresent(account -> {
            // Delete the account
            accountRepository.delete(account);
        });


        customerManagementClient.deleteCustomer(customerId);
        return "Customer deleted successfully";
    }

    private void validateCustomer(Long customerId) {
        try {
            customerManagementClient.getCustomerById(customerId);
        } catch (FeignException.NotFound e) {
            throw new CustomerNotFoundException(CUSTOMER_NOT_FOUND_MESSAGE + customerId);
        } catch (FeignException e) {
            throw new RuntimeException("Error communicating with Customer Management Service", e);
        }
    }


    private Account getOrCreateAccount(Long customerId) {
        Optional<Account> accountOptional = accountRepository.findByCustomerId(customerId);
        return accountOptional.orElseGet(() -> {
            Account newAccount = new Account();
            newAccount.setCustomerId(customerId);
            newAccount.setBalance(0.0);
            return accountRepository.save(newAccount);
        });
    }
}
