package com.AccountManagementService.exception;

/**
 * @author Mohit Jain
 * @version 08-01-2024
 * @since OpenJDK 17
 */
// CustomerNotFoundException.java

public class CustomerNotFoundException extends RuntimeException {
    public CustomerNotFoundException(String message) {
        super(message);
    }
}


