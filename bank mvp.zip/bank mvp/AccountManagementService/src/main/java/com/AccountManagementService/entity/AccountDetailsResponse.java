package com.AccountManagementService.entity;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Mohit Jain
 * @version 10-01-2024
 * @since OpenJDK 17
 */
@Getter
@Setter
public class AccountDetailsResponse {

    private Long customerId;
    private double balance;
    private String customerName;

    private String customerPhone;

    private String customerEmail;

    private String customerPermanentAddress;

    private String customerIdentityDocument;

    public AccountDetailsResponse(Account account, Customer customer) {
        this.customerId = account.getCustomerId();
        this.balance = account.getBalance();

        if (customer != null) {
            this.customerName = customer.getCustomerName();
            this.customerEmail = customer.getCustomerEmail();
            this.customerPhone = customer.getCustomerPhone();
            this.customerPermanentAddress = customer.getCustomerPermanentAddress();
            this.customerIdentityDocument = customer.getCustomerIdentityDocument();
        }
    }
}

