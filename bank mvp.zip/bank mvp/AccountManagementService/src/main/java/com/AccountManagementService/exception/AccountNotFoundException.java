package com.AccountManagementService.exception;

/**
 * @author Mohit Jain
 * @version 10-01-2024
 * @since OpenJDK 17
 */
// AccountNotFoundException.java

public class AccountNotFoundException extends RuntimeException {
    public AccountNotFoundException(String message) {
        super(message);
    }
}
