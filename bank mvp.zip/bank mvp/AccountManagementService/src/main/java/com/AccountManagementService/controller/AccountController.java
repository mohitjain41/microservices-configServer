package com.AccountManagementService.controller;

/**
 * @author Mohit Jain
 * @version 08-01-2024
 * @since OpenJDK 17
 */
// AccountController.java

import com.AccountManagementService.entity.Account;
import com.AccountManagementService.entity.AccountDetailsResponse;
import com.AccountManagementService.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/add-money/{customerId}")
    public ResponseEntity<String> addMoneyToAccount(@PathVariable Long customerId, @RequestParam double amount) {
        String message = accountService.addMoneyToAccount(customerId, amount);
        return ResponseEntity.status(HttpStatus.OK).body(message);
    }

    @PostMapping("/withdraw-money/{customerId}")
    public ResponseEntity<String> withdrawMoneyFromAccount(@PathVariable Long customerId, @RequestParam double amount) {
        String message = accountService.withdrawMoneyFromAccount(customerId, amount);
        return ResponseEntity.status(HttpStatus.OK).body(message);
    }

    @GetMapping("getDetails/{customerId}")
    public ResponseEntity<AccountDetailsResponse> getAccountDetails(@PathVariable Long customerId) {
        return ResponseEntity.ok(accountService.getAccountDetails(customerId));
    }

    @DeleteMapping("/customer/{customerId}")
    public ResponseEntity<String> deleteAccount(@PathVariable Long customerId) {
        String message = accountService.deleteAccount(customerId);
        return ResponseEntity.status(HttpStatus.OK).body(message);
    }
}
