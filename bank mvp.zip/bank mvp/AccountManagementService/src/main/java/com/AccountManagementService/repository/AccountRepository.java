package com.AccountManagementService.repository;

/**
 * @author Mohit Jain
 * @version 08-01-2024
 * @since OpenJDK 17
 */

// AccountRepository.java

import com.AccountManagementService.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {

    Optional<Account> findByCustomerId(Long customerId);

    void deleteByCustomerId(Long customerId);
}










