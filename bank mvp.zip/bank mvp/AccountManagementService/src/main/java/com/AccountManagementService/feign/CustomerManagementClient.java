package com.AccountManagementService.feign;

/**
 * @author Mohit Jain
 * @version 08-01-2024
 * @since OpenJDK 17
 */
// CustomerManagementClient.java

import com.AccountManagementService.entity.Customer;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "customer-management-service")
public interface CustomerManagementClient {

    @GetMapping("/customers/getById/{customerId}")
    void getCustomerById(@PathVariable Long customerId);

    @GetMapping("/customers/getById/{customerId}")
    Customer getCustomerDetails(@PathVariable Long customerId);
    @DeleteMapping("/customers/getById/{customerId}")
    void deleteCustomer(@PathVariable Long customerId);
}






