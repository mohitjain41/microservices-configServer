package com.AccountManagementService.entity;

/**
 * @author Mohit Jain
 * @version 05-01-2024
 * @since OpenJDK 17
 */
// Customer.java

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class Customer {

    @Id
    private Long customerId;
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private String customerPermanentAddress;
    private String customerIdentityDocument;

}
