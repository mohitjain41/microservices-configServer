package com.AccountManagementService.exception;

/**
 * @author Mohit Jain
 * @version 08-01-2024
 * @since OpenJDK 17
 */

// InsufficientFundsException.java

public class InsufficientFundsException extends RuntimeException {
    public InsufficientFundsException(String message) {
        super(message);
    }
}
