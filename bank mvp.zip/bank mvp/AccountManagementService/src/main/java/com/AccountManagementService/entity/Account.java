package com.AccountManagementService.entity;

/**
 * @author Mohit Jain
 * @version 08-01-2024
 * @since OpenJDK 17
 */
// Account.java

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Account {

    @Id
    private Long customerId;
    private double balance;



}
