package com.CustomerManagementService.service;

/**
 * @author Mohit Jain
 * @version 05-01-2024
 * @since OpenJDK 17
 */

// CustomerService.java

import com.CustomerManagementService.entity.Customer;
import com.CustomerManagementService.exception.CustomerNotFoundException;
import com.CustomerManagementService.feign.AccountManagementClient;
import com.CustomerManagementService.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AccountManagementClient accountManagementClient;

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerById(Long customerId) {
        return customerRepository.findById(customerId)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + customerId));
    }


    public String addCustomer(Customer customer) {
        Customer savedCustomer = customerRepository.save(customer);
        return "Customer added successfully with ID: " + savedCustomer.getCustomerId();
    }

    public String updateCustomer(Long customerId, Customer updatedCustomer) {
        if (customerRepository.existsById(customerId)) {
            updatedCustomer.setCustomerId(customerId);
            customerRepository.save(updatedCustomer);
            return "Customer updated successfully";
        } else {
            throw new CustomerNotFoundException("Customer not found with id: " + customerId);
        }
    }

    public String deleteCustomer(Long customerId) {
        Optional<Customer> customerOptional = customerRepository.findById(customerId);
        if (customerOptional.isPresent()) {
            customerRepository.deleteById(customerId);
            return "Customer deleted successfully with id: " + customerId;
        } else {
            throw new CustomerNotFoundException("Customer not found with id: " + customerId);
        }
    }
}

