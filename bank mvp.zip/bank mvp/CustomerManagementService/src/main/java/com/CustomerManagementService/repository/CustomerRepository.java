package com.CustomerManagementService.repository;

/**
 * @author Mohit Jain
 * @version 05-01-2024
 * @since OpenJDK 17
 */
// CustomerRepository.java

import com.CustomerManagementService.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

}
