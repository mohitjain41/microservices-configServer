package com.CustomerManagementService.exception;

/**
 * @author Mohit Jain
 * @version 05-01-2024
 * @since OpenJDK 17
 */
// CustomerNotFoundException.java

public class CustomerNotFoundException extends RuntimeException {
    public CustomerNotFoundException(String message) {
        super(message);
    }
}
