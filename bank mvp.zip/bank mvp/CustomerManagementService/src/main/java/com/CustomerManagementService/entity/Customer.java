package com.CustomerManagementService.entity;

/**
 * @author Mohit Jain
 * @version 05-01-2024
 * @since OpenJDK 17
 */
// Customer.java

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;

    private String customerName;

    private String customerPhone;

    private String customerEmail;

    private String customerPermanentAddress;

    private String customerIdentityDocument;

}