package com.CustomerManagementService.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * @author Mohit Jain
 * @version 11-01-2024
 * @since OpenJDK 17
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Account {


    private String accountId;
    private String accountType;
    Date accountOpeningDate;
    Date lastActivity;
    private int balance;
    private String customerId;
    Customer customer;

}
