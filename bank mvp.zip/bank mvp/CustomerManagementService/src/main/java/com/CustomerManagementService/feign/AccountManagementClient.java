package com.CustomerManagementService.feign;

/**
 * @author Mohit Jain
 * @version 05-01-2024
 * @since OpenJDK 17
 */
// AccountManagementClient.java

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Component
@FeignClient(name = "account-management-service")
public interface AccountManagementClient {

    @DeleteMapping("accounts/customer/{customerId}")
    void deleteCustomer(@PathVariable Long customerId);
}
