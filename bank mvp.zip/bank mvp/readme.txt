This is banking microservice MVP system

It consist of 5 microservices
1. Eureka server
2. Centralised configration Management
3. API-Gateway
4. Customer-Management-Service
5. Account-Management-service

To check run the services in same to order so that everything works fine

Eureka server ->  http://localhost:8761/ 
	check all services are up and running
	

Centralised configuration Management
	As per the requirement, it contains eureka configurations for api gateway, customer and account management services.

Services APIs To check on hitting Postman
CustomerManagementService
1. Add customer
	Post Method
		url: http://localhost:8081/customers/addNew
		sample pojo: 
		{
			"customerName" : "Test user",
			"customerEmail" : "test@dev.in",
			"customerPhone" : "9876543210",
			"customerPermanentAddress" : "Jabalpur, India",
			"customerIdentityDocument" : "Pan card"
		}

2. Get All Customers
	Get method
		url:http://localhost:8081/customers/getAll

3. Get Single Customer
	Get method
		url:http://localhost:8081/customers/getById/{customerId}
		
4. Update Customer Details
	Post Method
		url: http://localhost:8081/update/customers/{customerId}
		sample pojo: 
		{
			"customerName" : "mohit jain",
			"customerEmail" : "test@dev.in",
			"customerPhone" : "9876543210",
			"customerPermanentAddress" : "Jabalpur, India",
			"customerIdentityDocument" : "Pan card"
		}

		
5. Delete Customer 
	Delete method
		url:http://localhost:8081/customers/delete/{customerId}
		
		

Account Management service

1. Add Money
	Post method 
		url: http://localhost:8082/accounts/add-money/{customerId}?amount={amount}

2. Withdraw money
	post Method
		url: http://localhost:8082/accounts/withdraw-money/{customerId}?amount={amount}

3. Get Account Details
	get Method
		url: http://localhost:8082/accounts/getDetails/{customerId}

4.Delete account
	Delete method
		url: http://localhost:8082/accounts/customer/{custoemrId}